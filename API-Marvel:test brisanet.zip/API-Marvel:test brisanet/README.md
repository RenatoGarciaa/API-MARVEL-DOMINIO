# API-Marvel

<table>
    <tr>
        <td>
        <sub>
       	 	<h2>
			Este projeto foi desenvolvido com a finalidade de ser submetido no teste aplicado pela empresa brisanet, o mesmo foi desenvolvido juntamente com a integração de uma API da Marvel usando JavaScript</br></br>
			Os métodos usados ​​para o projeto:</br>
			GET - /v1/public/characters </br>
			GET - /V1/public/characters/{characterId}/stories</br>
			Se você quiser ver mais sobre os métodos, aqui os documentos:
			<a href="https://developer.marvel.com/docs">Marvel API</a>
       	 	</h2>
        </sub>
        </td>
    </tr>
</table>


